﻿--Ubung 1+2
-- Functie pentru validarea ID-ului (product_id)
CREATE FUNCTION validateProductId (@Id INT)
RETURNS BIT AS
BEGIN
    RETURN CASE WHEN @Id IS NOT NULL AND @Id > 0 THEN 1 ELSE 0 END;
END;
GO

-- Functie pentru validarea sirurilor de caractere (name, description)
CREATE FUNCTION validateText (@string VARCHAR(50))
RETURNS BIT AS
BEGIN
    RETURN CASE WHEN LEN(@string) > 0 THEN 1 ELSE 0 END;
END;
GO

-- Functie pentru validarea prețului (price)
CREATE FUNCTION validatePrice (@price FLOAT)
RETURNS BIT AS
BEGIN
    RETURN CASE WHEN @price IS NOT NULL AND @price > 0 THEN 1 ELSE 0 END;
END;
GO

-- Functie pentru validarea datei de expirare (expiration_date > production_date)
CREATE FUNCTION validateExpirationDate (@production_date DATE, @expiration_date DATE)
RETURNS BIT AS
BEGIN
    RETURN CASE WHEN @expiration_date > @production_date THEN 1 ELSE 0 END;
END;
GO

--procedura de inserare a unui produs
CREATE PROCEDURE insertProduct
    @product_id INT,
    @name VARCHAR(50),
    @description VARCHAR(255),
    @price FLOAT,
    @production_date DATE,
    @expiration_date DATE,
    @category INT
AS
BEGIN
    -- Validare ID
    IF dbo.validateProductId(@product_id) = 0
    BEGIN
        PRINT 'Invalid Product ID';
        RETURN;
    END;

    -- Verificare ID existent
    IF EXISTS (SELECT 1 FROM Product WHERE product_id = @product_id)
    BEGIN
        PRINT 'Product ID already exists';
        RETURN;
    END;

    -- Validare Name
    IF dbo.validateText(@name) = 0
    BEGIN
        PRINT 'Invalid Name';
        RETURN;
    END;

    -- Validare Description
    IF dbo.validateText(@description) = 0
    BEGIN
        PRINT 'Invalid Description';
        RETURN;
    END;

    -- Validare Price
    IF dbo.validatePrice(@price) = 0
    BEGIN
        PRINT 'Invalid Price';
        RETURN;
    END;

    -- Validare Expiration Date
    IF dbo.validateExpirationDate(@production_date, @expiration_date) = 0
    BEGIN
        PRINT 'Invalid Expiration Date';
        RETURN;
    END;

    -- Inserare în tabel
    INSERT INTO Product (product_id, name, description, price, production_date, expiration_date, category)
    VALUES (@product_id, @name, @description, @price, @production_date, @expiration_date, @category);

    PRINT 'Product inserted successfully';
END;
GO
EXEC insertProduct 
    @product_id = 6, 
    @name = 'Dark Chocolate', 
    @description = '85% cocoa premium chocolate', 
    @price = 12.99, 
    @production_date = '2024-01-01', 
    @expiration_date = '2025-01-01', 
    @category = 1;

CREATE VIEW getProductAndCategory
AS
    SELECT 
        p.name AS product_name_view, 
        p.category AS product_category_view
    FROM Product AS p;
GO

-- Selectare date din vizualizare
SELECT * FROM getProductAndCategory;

--functie tabelara pentru produse expirate
CREATE FUNCTION getExpiredProducts (@current_date DATE)
RETURNS @expiredProducts TABLE (
    product_name VARCHAR(50),
    expiration_date DATE
)
AS
BEGIN
    INSERT INTO @expiredProducts
    SELECT 
        name, 
        expiration_date
    FROM Product
    WHERE expiration_date < @current_date;

    RETURN;
END;
GO

--interogare combinata
-- Obtine produsele expirate și durata lor de valabilitate din vizualizare
CREATE FUNCTION GetExpiredProductsWithShelfLife (@current_date DATE)
RETURNS @ExpiredProducts TABLE (
        product_name_func VARCHAR(50),
        category_func INT,
        production_date_func DATE,
        expiration_date_func DATE
    )
AS
BEGIN
    -- Inserare produse expirate in tabelul returnat
    INSERT INTO @ExpiredProducts
    SELECT 
        p.name AS product_name_func,
        p.category AS category_func,
        p.production_date AS production_date_func,
        p.expiration_date AS expiration_date_func
    FROM Product p
    WHERE p.expiration_date < @current_date;

    -- Daca nu exista produse expirate
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT INTO @ExpiredProducts
        VALUES ('No expired products found', '', NULL, NULL);
    END;

    RETURN;
END;
GO
-- Selectare produse expirate și durata lor de valabilitate
SELECT DISTINCT 
    ep.product_name_func AS expired_product_name,
    ep.category_func AS product_category,
    ep.production_date_func AS production_date,
    ep.expiration_date_func AS expiration_date,
    v.product_category_view AS category_from_view
FROM dbo.GetExpiredProductsWithShelfLife(GETDATE()) ep
INNER JOIN getProductAndCategory v 
    ON ep.product_name_func = v.product_name_view;



--UBUNG 3
CREATE TABLE LogTriggerTable (
    action_date DATETIME,       
    action_type CHAR(1),       
    table_name VARCHAR(50),     
    affected_tuples INT         
);
GO

CREATE OR ALTER TRIGGER ProductTableTrigger
    ON Product
    FOR INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActionType AS CHAR(1);
    DECLARE @TableName AS VARCHAR(50);
    DECLARE @AffectedTuples AS INT;

    -- Determinarea tipului de actiune
    IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
    BEGIN
        SET @ActionType = 'U'; -- UPDATE
        SET @AffectedTuples = (SELECT COUNT(*) FROM inserted);
    END
    ELSE IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        SET @ActionType = 'I'; -- INSERT
        SET @AffectedTuples = (SELECT COUNT(*) FROM inserted);
    END
    ELSE IF EXISTS (SELECT 1 FROM deleted)
    BEGIN
        SET @ActionType = 'D'; -- DELETE
        SET @AffectedTuples = (SELECT COUNT(*) FROM deleted);
    END;

    -- Numele tabelei afectate
    SET @TableName = OBJECT_NAME(OBJECT_ID('product'));

    -- Inserarea in tabelul de log
    INSERT INTO LogTriggerTable (action_date, action_type, table_name, affected_tuples)
    VALUES (GETDATE(), @ActionType, @TableName, @AffectedTuples);
END;
GO

INSERT INTO Product (product_id, name, description, price, production_date, expiration_date, category)
VALUES 
    (7, 'Milk Chocolate', 'Smooth milk chocolate', 3.99, '2024-01-15', '2024-07-15', 1),
    (8, 'Chocolate Cookies', 'Crunchy cookies with chocolate', 4.99, '2024-02-01', '2024-08-01', 2);

DELETE FROM Product WHERE product_id = 7;
UPDATE Product SET price = 5.49 WHERE product_id = 8;

SELECT * FROM LogTriggerTable;


--UBUNG 4
CREATE OR ALTER PROCEDURE UpdateOrDeleteProduct (
    @ProductId INT, 
    @Category INT
)
AS
BEGIN
    -- Daca categoria produsului este "1" (sau alt criteriu specific)
    IF EXISTS (SELECT 1 FROM product WHERE category = @Category)
    BEGIN
        -- Actualizeaza pretul produsului adaugand o valoare fixa, de exemplu +1
        UPDATE Product 
        SET price = price + 1 
        WHERE product_id = @ProductId;
    END
    ELSE
    BEGIN
        -- Daca nu se indeplineste conditia, se sterge produsul
        DELETE FROM Product WHERE product_id = @ProductId;
    END
END;
GO

CREATE OR ALTER PROCEDURE CursorProducts
AS
BEGIN
    DECLARE @ProductId INT;
    DECLARE @Category INT;

    -- Definirea cursorului care selecteaza produsul si categoria
    DECLARE productCursor CURSOR FOR
        SELECT product_id, category 
        FROM Product;

    OPEN productCursor;

    -- Citirea fiecarui rand din cursor
    FETCH NEXT FROM productCursor INTO @ProductId, @Category;
    
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        -- Executarea procedurii pentru fiecare produs
        EXEC UpdateOrDeleteProduct @ProductId, @Category;
        
        -- Citirea urmatorului rand
        FETCH NEXT FROM productCursor INTO @ProductId, @Category;
    END

    -- inchidem si eliberam cursorul
    CLOSE productCursor;
    DEALLOCATE productCursor;
END;
GO
EXEC CursorProducts;
SELECT * FROM Product;  

INSERT INTO Product (product_id, name, description, price, production_date, expiration_date, category)
VALUES 
    (9, 'Dark Chocolate', 'Rich dark chocolate', 3.50, '2024-01-10', '2024-07-10', 1),
    (10, 'Milk Chocolate', 'Smooth milk chocolate', 4.00, '2024-02-01', '2024-08-01', 2),
    (11, 'Chocolate Cookies', 'Crispy chocolate cookies', 2.50, '2024-03-01', '2024-09-01', 1);

UPDATE Product 
SET price = price + 1
WHERE category = 1;

DELETE FROM RawMaterial
WHERE product_id IN (SELECT product_id FROM Product WHERE category != 1);

DELETE FROM Product 
WHERE category != 1;
