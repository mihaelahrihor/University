//
// Created by Dell on 5/24/2024.
//

#pragma once
#include "SortedMultiMap.h"

class IT{
    friend class SortedMultiMap;
private:
    const SortedMultiMap& map;
    IT(const SortedMultiMap& map, TKey c);
    int currentValueIndex;
    int currentKeyIndex;

public:
    void first();
    void next();
    bool valid() const;
    TElem getCurrent() const;
};

