
//29. ADT SortedMultiMap – repräsentiert mithilfe einer SLLA mit eindeutigen Schlüsseln
//(key) und sortiert mithilfe einer Relation auf den Schlüsseln (key). Für jeden Schlüssel
//speichert man eine SLLA von Werten (value).

#pragma once
//DO NOT INCLUDE SMMITERATOR

//DO NOT CHANGE THIS PART
#include <vector>
#include <utility>
typedef int TKey;
typedef int TValue;
typedef std::pair<TKey, TValue> TElem;
#define NULL_TVALUE -111111
#define NULL_TELEM pair<TKey, TValue>(-111111, -111111);
using namespace std;
class SMMIterator;
typedef bool(*Relation)(TKey, TKey);

struct ValueNode {
    TValue value;
    int nextValue;
};

struct Node {
    TKey info;
    int next;
    int valueHead;
    int firstValueEmpty;
    int valueLength;
    int valueCapacity;
    ValueNode* values;
};

class SortedMultiMap {
    friend class SMMIterator;
private:

    Relation relation;
    int keyHead;
    int firstKeyEmpty;
    Node* elements;
    int capacity;
    int nrElems;

public:

    // constructor
    SortedMultiMap(Relation r);

    void resizeUp();
    void resizeDown();

    //adds a new key value pair to the sorted multimap
    void add(TKey c, TValue v);

    //returns the values belonging to a given key
    vector<TValue> search(TKey c) const;

    //removes a key value pair from the sorted multimap
    //returns true if the pair was removed (it was part of the multimap), false if nothing is removed
    bool remove(TKey c, TValue v);

    //returns the number of key-value pairs from the sorted multimap
    int size() const;

    //verifies if the sorted multimap is empty
    bool isEmpty() const;

    // returns an iterator for the sorted multimap. The iterator will return the pairs as required by the relation (given to the constructor)
    SMMIterator iterator() const;

    // destructor
    ~SortedMultiMap();
};