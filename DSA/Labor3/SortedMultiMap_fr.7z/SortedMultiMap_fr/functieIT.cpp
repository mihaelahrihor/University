//
// Created by Dell on 5/24/2024.
//
#include "functieIT.h"
#include "SortedMultiMap.h"

IT::IT(const SortedMultiMap& d, TKey c) : map(d) {
    c = map.elements[currentKeyIndex].info;
    currentValueIndex = map.elements[currentKeyIndex].valueHead;
}

//theta 1
//post: true daca valoarea este valida sau fals contrar
bool IT::valid() const {
    return currentValueIndex != -1;
}

//theta 1
//post: indexul primei valori a unei chei
void IT::first() {
    currentValueIndex = map.elements[currentKeyIndex].valueHead;
}

//theta 1
//post: urmatoarea valoare
void IT::next() {
    if (!valid()){
        throw exception();
    }
    currentValueIndex = map.elements[currentKeyIndex].values[currentValueIndex].nextValue;
}

//theta 1
//post: valoarea curecta pe care ne aflam
void IT::getCurrent() const {
    if (!valid()){
        throw exception();
    }
    TValue currentValue = map.elements[currentKeyIndex].values[currentValueIndex].value;
    return currentValue;
}

