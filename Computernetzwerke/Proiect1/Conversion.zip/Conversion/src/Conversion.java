public class Conversion {
    public static String convertNumber(String number, int base) {
        try {
            if (base == 10) {
                // Conversie din baza 2 în baza 10
                return String.valueOf(Integer.parseInt(number, 2));
            } else if (base == 2) {
                // Conversie din baza 10 în baza 2
                return Integer.toBinaryString(Integer.parseInt(number));
            } else {
                return "Unsupported base";
            }
        } catch (NumberFormatException e) {
            return "Invalid input";
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java Conversion <number> <base>");
            return;
        }

        String number = args[0];
        int base;
        try {
            base = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("Base must be a number (2 or 10)");
            return;
        }

        String result = convertNumber(number, base);
        System.out.println(result);
    }
}
