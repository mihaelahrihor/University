import socket
import subprocess


def handle_client(client_socket):
    data = client_socket.recv(1024).decode()
    number, base = data.split()
    result = convert_number_with_java(number, base)
    client_socket.send(result.endcode())

def convert_number_with_java (number, base):
    try:
        java_command = f"java Conversion {number} {base}"
        result = subprocess.check_output(java_command, shell=True).decode()
        return result.strip()
    except subprocess.CalledProcessError:
        return "Conversion failed"

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0',12345))
    server_socket.listen()

    print("Server wartet auf Verbindungen...")
    while True:
        client_socket, _ = server_socket.accept()
        print("Client verbundet.")
        handle_client(client_socket)
        client_socket.close()

if __name__ == "__main__":
    main()
