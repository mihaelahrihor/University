import socket


def send_number_and_base(number, base):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect(('localhost', 12345))
        client_socket.send(f"{number} {base}".encode())
        result = client_socket.recv(1024).decode()
        print(f"Umgewandelte Zahl: {result}")

if __name__ == "__main__":
    number, base = input("Geben Sie eine Nummer und die gewunschte Basis ein (z. B. 1101 10): ").split()
    send_number_and_base(number, base)
